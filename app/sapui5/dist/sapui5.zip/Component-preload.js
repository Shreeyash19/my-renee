//@ui5-bundle my-renee/Component-preload.js
sap.ui.require.preload({
	"my-renee/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"my-renee","applicationVersion":{"version":"1.0.0"},"type":"application","title":"","description":"A simple CAP project.","i18n":"i18n/i18n.properties"},"sap.cloud":{"public":true,"service":"my-renee.service"}}'
});
//# sourceMappingURL=Component-preload.js.map

sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("sap.btp.sourcetypes.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map
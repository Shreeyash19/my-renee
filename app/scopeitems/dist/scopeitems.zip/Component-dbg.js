sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("sap.btp.scopeitems.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);